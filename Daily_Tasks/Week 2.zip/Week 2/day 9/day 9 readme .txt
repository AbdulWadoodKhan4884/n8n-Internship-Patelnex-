{
  "name": "day 9",
  "nodes": [
    {
      "parameters": {

      },
      "type": "n8n-nodes-base.manualTrigger",
      "typeVersion": 1,
      "position": [0, 0],
      "id": "fee7d16d-1712-4fff-8d6f-4ffae5c77e80",
      "name": "When clicking ‘Execute workflow’"
    },
    {
      "parameters": {
        "jsCode": "\nconst rawData = [\n  { name: \"  ali khan  \", email: \"ALI@Example.com\", score: 92 },\n  { name: \"sara AHMED\", email: \"Sara@EXAMPLE.com\", score: 78 },\n  { name: \"MUHAMMAD bilal\", email: \"bilal@example.COM\", score: 65 },\n  { name: \"  zara sheikh\", email: \"ZARA@example.com\", score: 55 },\n  { name: \"usman TARIQ  \", email: \"Usman@Example.Com\", score: 88 },\n  { name: \"hina raza\", email: \"HINA@example.com\", score: 71 },\n  { name: \"OMAR farooq\", email: \"omar@EXAMPLE.com\", score: 45 },\n  { name: \"noor FATIMA\", email: \"Noor@Example.com\", score: 95 },\n  { name: \"kamran iqbal\", email: \"KAMRAN@example.COM\", score: 60 },\n  { name: \"  ayesha malik  \", email: \"ayesha@EXAMPLE.com\", score: 83 },\n  { name: \"ahmed ALI\", email: \"AHMED@example.com\", score: 30 },\n  { name: \"fatima NOOR\", email: \"fatima@Example.COM\", score: 72 },\n  { name: \"bilal AHMED\", email: \"Bilal2@example.com\", score: 68 },\n  { name: \"  sana khan\", email: \"SANA@example.com\", score: 90 },\n  { name: \"hassan RAZA  \", email: \"Hassan@EXAMPLE.com\", score: 40 }\n];\n\n// Helper: title case a name\nfunction toTitleCase(str) {\n  return str\n    .trim()\n    .toLowerCase()\n    .split(\" \")\n    .filter(Boolean)\n    .map(word =\u003E word.charAt(0).toUpperCase() + word.slice(1))\n    .join(\" \");\n}\n\n// Helper: convert numeric score to letter grade\nfunction getGrade(score) {\n  if (score \u003E= 90) return \"A\";\n  if (score \u003E= 80) return \"B\";\n  if (score \u003E= 70) return \"C\";\n  if (score \u003E= 60) return \"D\";\n  return \"F\";\n}\n\n// Step 1: normalize + compute grade using .map()\nconst processed = rawData.map(record =\u003E ({\n  name: toTitleCase(record.name),\n  email: record.email.trim().toLowerCase(),\n  score: record.score,\n  grade: getGrade(record.score)\n}));\n\n// Step 2: keep only grade A or B using .filter()\nconst filtered = processed.filter(r =\u003E r.grade === \"A\" || r.grade === \"B\");\n\n// Return in n8n's expected item format\nreturn filtered.map(item =\u003E ({ json: item }));"
      },
      "type": "n8n-nodes-base.code",
      "typeVersion": 2,
      "position": [208, 0],
      "id": "0eb709ad-b3b4-49d9-81bf-9b1aa65415a6",
      "name": "Code in JavaScript"
    }
  ],
  "pinData": {

  },
  "connections": {
    "When clicking ‘Execute workflow’": {
      "main": [
        [
          {
            "node": "Code in JavaScript",
            "type": "main",
            "index": 0
          }
        ]
      ]
    }
  },
  "active": false,
  "settings": {
    "executionOrder": "v1",
    "binaryMode": "separate"
  },
  "versionId": "e473000f-3779-4db4-9a31-13352b9bbb31",
  "meta": {
    "instanceId": "854f34b4ed7db77ccb3a9c25a45847fc205f644339f1b150a22247a3bc76bf7b"
  },
  "nodeGroups": [],
  "id": "VIcSD8xGgmeKJz2G",
  "tags": []
}