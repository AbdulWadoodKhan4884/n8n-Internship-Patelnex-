{
  "name": "My workflow 5",
  "nodes": [
    {
      "parameters": {
        "httpMethod": "POST",
        "path": "new-lead",
        "responseMode": "responseNode",
        "options": {

        }
      },
      "type": "n8n-nodes-base.webhook",
      "typeVersion": 2.1,
      "position": [0, 0],
      "id": "a282f41c-44fc-4c46-aa98-f7e39d6edc92",
      "name": "Webhook",
      "webhookId": "c4e26a7a-bf3e-432b-b896-86c82c99dfd1"
    },
    {
      "parameters": {
        "conditions": {
          "options": {
            "caseSensitive": true,
            "leftValue": "",
            "typeValidation": "strict",
            "version": 3
          },
          "conditions": [
            {
              "id": "b9bf6454-8eb7-4661-9978-a88e9e5191bb",
              "leftValue": "={{ $json.body.name }}",
              "rightValue": "",
              "operator": {
                "type": "string",
                "operation": "notEmpty",
                "singleValue": true
              }
            },
            {
              "id": "1b41b915-c0f9-4683-9170-6bd93e64bd2f",
              "leftValue": "={{ $json.body.email }}",
              "rightValue": "",
              "operator": {
                "type": "string",
                "operation": "notEmpty",
                "singleValue": true
              }
            },
            {
              "id": "cb364e20-79d0-4e0c-870a-ae2259e42ff9",
              "leftValue": "={{ $json.body.company }}",
              "rightValue": "",
              "operator": {
                "type": "string",
                "operation": "notEmpty",
                "singleValue": true
              }
            }
          ],
          "combinator": "and"
        },
        "options": {

        }
      },
      "type": "n8n-nodes-base.filter",
      "typeVersion": 2.3,
      "position": [208, 0],
      "id": "39a76877-1f5e-4cbc-9f54-69a183d54c95",
      "name": "Filter"
    },
    {
      "parameters": {
        "url": "=https://www.disify.com/api/email/{{ $json.body.email }}",
        "options": {

        }
      },
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.4,
      "position": [416, 0],
      "id": "a206ec3b-1c39-4c11-aed4-ad79a4b0fff7",
      "name": "HTTP Request"
    },
    {
      "parameters": {
        "assignments": {
          "assignments": [
            {
              "id": "1f4653d1-51ea-4f1b-95a7-b4cd35edd840",
              "name": "name",
              "value": "={{ $('Webhook').item.json.body.name }}",
              "type": "string"
            },
            {
              "id": "598c239e-e3cb-42c9-b4a1-37160270b7f1",
              "name": "email",
              "value": "={{ $('Webhook').item.json.body.email }}",
              "type": "string"
            },
            {
              "id": "1bf44436-12ca-47f1-ae4a-98d71de3a98b",
              "name": "",
              "value": "",
              "type": "string"
            },
            {
              "id": "efa64c6d-9878-4e8c-9d30-d177fc81dee0",
              "name": "company",
              "value": "={{ $('Webhook').item.json.body.company }}",
              "type": "string"
            },
            {
              "id": "21d23d68-5d30-4ec4-b5b6-39c83c5858b5",
              "name": "interest",
              "value": "={{ $('Webhook').item.json.body.interest }}",
              "type": "string"
            },
            {
              "id": "5bdbdde1-82b6-40ba-ad7c-940e3944aa91",
              "name": "email_valid ",
              "value": "={{ $json.format }}",
              "type": "string"
            },
            {
              "id": "32d978b5-82be-4f2c-befe-c5a2c8bf6c75",
              "name": "is_disposable",
              "value": "={{ $json.disposable }}",
              "type": "string"
            }
          ]
        },
        "options": {

        }
      },
      "type": "n8n-nodes-base.set",
      "typeVersion": 3.4,
      "position": [624, 0],
      "id": "3b1d7b4f-2e99-4fa4-bcf7-023403624e61",
      "name": "Edit Fields"
    },
    {
      "parameters": {
        "operation": "append",
        "documentId": {
          "__rl": true,
          "value": "1-EuC1uK0kXOi8lvNWhO8oZS1L4Cl6VD-dvJSrRJRciA",
          "mode": "list",
          "cachedResultName": "day 11",
          "cachedResultUrl": "https://docs.google.com/spreadsheets/d/1-EuC1uK0kXOi8lvNWhO8oZS1L4Cl6VD-dvJSrRJRciA/edit?usp=drivesdk"
        },
        "sheetName": {
          "__rl": true,
          "value": "gid=0",
          "mode": "list",
          "cachedResultName": "Sheet1",
          "cachedResultUrl": "https://docs.google.com/spreadsheets/d/1-EuC1uK0kXOi8lvNWhO8oZS1L4Cl6VD-dvJSrRJRciA/edit#gid=0"
        },
        "columns": {
          "mappingMode": "defineBelow",
          "value": {
            "Name ": "={{ $json.name }}",
            "Email": "={{ $json.email }}",
            "Comapny": "={{ $json.company }}",
            "Interest": "={{ $json.interest }}",
            "Evaild": "={{ $json.email_valid }}",
            "Disposable": "={{ $json.is_disposable }}",
            "Timestamp": "={{ $now }}"
          },
          "matchingColumns": [],
          "schema": [
            {
              "id": "Name ",
              "displayName": "Name ",
              "required": false,
              "defaultMatch": false,
              "display": true,
              "type": "string",
              "canBeUsedToMatch": true,
              "removed": false
            },
            {
              "id": "Email",
              "displayName": "Email",
              "required": false,
              "defaultMatch": false,
              "display": true,
              "type": "string",
              "canBeUsedToMatch": true,
              "removed": false
            },
            {
              "id": "Comapny",
              "displayName": "Comapny",
              "required": false,
              "defaultMatch": false,
              "display": true,
              "type": "string",
              "canBeUsedToMatch": true,
              "removed": false
            },
            {
              "id": "Interest",
              "displayName": "Interest",
              "required": false,
              "defaultMatch": false,
              "display": true,
              "type": "string",
              "canBeUsedToMatch": true,
              "removed": false
            },
            {
              "id": "Evaild",
              "displayName": "Evaild",
              "required": false,
              "defaultMatch": false,
              "display": true,
              "type": "string",
              "canBeUsedToMatch": true,
              "removed": false
            },
            {
              "id": "Disposable",
              "displayName": "Disposable",
              "required": false,
              "defaultMatch": false,
              "display": true,
              "type": "string",
              "canBeUsedToMatch": true,
              "removed": false
            },
            {
              "id": "Timestamp",
              "displayName": "Timestamp",
              "required": false,
              "defaultMatch": false,
              "display": true,
              "type": "string",
              "canBeUsedToMatch": true,
              "removed": false
            }
          ],
          "attemptToConvertTypes": false,
          "convertFieldsToString": false
        },
        "options": {

        }
      },
      "type": "n8n-nodes-base.googleSheets",
      "typeVersion": 4.7,
      "position": [832, 0],
      "id": "a49df154-bf8c-404d-b6d7-925c47d217bf",
      "name": "Append row in sheet",
      "credentials": {
        "googleSheetsOAuth2Api": {
          "id": "HqHt47uNPjpk4SFF",
          "name": "Google Sheets account"
        }
      }
    },
    {
      "parameters": {
        "sendTo": "wadoodk212@gmail.com",
        "subject": "=New Lead: {{ $('Edit Fields').item.json.name }}",
        "message": "=New lead received:\n\nName: {{ $('Edit Fields').item.json.name }}\nCompany: {{ $('Edit Fields').item.json.company }}\nEmail: {{ $('Edit Fields').item.json.email }} \nDisposable: {{ $('Edit Fields').item.json.is_disposable }})\nInterest: {{ $('Edit Fields').item.json.interest }}",
        "options": {

        }
      },
      "type": "n8n-nodes-base.gmail",
      "typeVersion": 2.2,
      "position": [1040, 0],
      "id": "5f3f9804-9a07-4c70-abc5-2a1cbc9bcdd4",
      "name": "Send a message",
      "webhookId": "9ab57483-d357-49c8-ab63-26598dc1421c",
      "credentials": {
        "gmailOAuth2": {
          "id": "jYE3IuNJMsHFVKYn",
          "name": "Gmail account"
        }
      }
    },
    {
      "parameters": {
        "respondWith": "json",
        "responseBody": "{ \"status\": \"success\", \"message\": \"Lead received and processed\" }",
        "options": {

        }
      },
      "type": "n8n-nodes-base.respondToWebhook",
      "typeVersion": 1.5,
      "position": [1248, 0],
      "id": "83d1729e-aada-4ca2-a028-8d8b61559e07",
      "name": "Respond to Webhook"
    }
  ],
  "pinData": {

  },
  "connections": {
    "Webhook": {
      "main": [
        [
          {
            "node": "Filter",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Filter": {
      "main": [
        [
          {
            "node": "HTTP Request",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "HTTP Request": {
      "main": [
        [
          {
            "node": "Edit Fields",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Edit Fields": {
      "main": [
        [
          {
            "node": "Append row in sheet",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Append row in sheet": {
      "main": [
        [
          {
            "node": "Send a message",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Send a message": {
      "main": [
        [
          {
            "node": "Respond to Webhook",
            "type": "main",
            "index": 0
          }
        ]
      ]
    }
  },
  "active": false,
  "settings": {
    "executionOrder": "v1",
    "binaryMode": "separate"
  },
  "versionId": "6ed18745-9882-4ae1-a2b5-7558d71b7d8d",
  "meta": {
    "templateCredsSetupCompleted": true,
    "instanceId": "854f34b4ed7db77ccb3a9c25a45847fc205f644339f1b150a22247a3bc76bf7b"
  },
  "nodeGroups": [],
  "id": "RBptGQqH9NdW1Tj9",
  "tags": []
}