{
  "name": "My workflow 4",
  "nodes": [
    {
      "parameters": {
        "httpMethod": "POST",
        "path": "a2b5d21c-484c-45e9-b531-ed2145d9e9bb",
        "options": {

        }
      },
      "type": "n8n-nodes-base.webhook",
      "typeVersion": 2.1,
      "position": [0, 0],
      "id": "61c8d5db-cedf-4abb-82e8-0a64f3e55bae",
      "name": "Webhook",
      "webhookId": "a2b5d21c-484c-45e9-b531-ed2145d9e9bb"
    },
    {
      "parameters": {
        "includeOtherFields": true,
        "options": {

        }
      },
      "type": "n8n-nodes-base.set",
      "typeVersion": 3.4,
      "position": [208, 0],
      "id": "d7018308-eb97-4bee-b970-ad371e283cc2",
      "name": "Edit Fields"
    },
    {
      "parameters": {
        "conditions": {
          "options": {
            "caseSensitive": true,
            "leftValue": "",
            "typeValidation": "strict",
            "version": 3
          },
          "conditions": [
            {
              "id": "cbbd8261-a735-41b9-a62c-adcc3359a899",
              "leftValue": "={{ $json.body.name }}",
              "rightValue": "",
              "operator": {
                "type": "string",
                "operation": "notEmpty",
                "singleValue": true
              }
            },
            {
              "id": "78aa1dbd-97a3-4891-8b1b-61d546c2fe7f",
              "leftValue": "={{ $json.body.email }}",
              "rightValue": "",
              "operator": {
                "type": "string",
                "operation": "notEmpty",
                "singleValue": true
              }
            },
            {
              "id": "9de7a7ea-9c11-4c3e-9880-cf014a169348",
              "leftValue": "={{ $json.body.message }}",
              "rightValue": "",
              "operator": {
                "type": "string",
                "operation": "notEmpty",
                "singleValue": true
              }
            }
          ],
          "combinator": "and"
        },
        "options": {

        }
      },
      "type": "n8n-nodes-base.filter",
      "typeVersion": 2.3,
      "position": [416, 0],
      "id": "14622073-43af-44c4-b133-340921104829",
      "name": "Filter"
    },
    {
      "parameters": {
        "operation": "append",
        "documentId": {
          "__rl": true,
          "value": "12XZYA770SHdWmcVrt12Oa2sb3GtMKZo7_Qm5R_ddyCw",
          "mode": "list",
          "cachedResultName": "day 10 webhooks",
          "cachedResultUrl": "https://docs.google.com/spreadsheets/d/12XZYA770SHdWmcVrt12Oa2sb3GtMKZo7_Qm5R_ddyCw/edit?usp=drivesdk"
        },
        "sheetName": {
          "__rl": true,
          "value": "gid=0",
          "mode": "list",
          "cachedResultName": "Sheet1",
          "cachedResultUrl": "https://docs.google.com/spreadsheets/d/12XZYA770SHdWmcVrt12Oa2sb3GtMKZo7_Qm5R_ddyCw/edit#gid=0"
        },
        "columns": {
          "mappingMode": "defineBelow",
          "value": {
            "Name": "={{ $json.body.name }}",
            "Email": "={{ $json.body.email }}",
            "Message": "={{ $json.body.message }}",
            "Timestamp": "={{ $now }}"
          },
          "matchingColumns": [],
          "schema": [
            {
              "id": "Name",
              "displayName": "Name",
              "required": false,
              "defaultMatch": false,
              "display": true,
              "type": "string",
              "canBeUsedToMatch": true
            },
            {
              "id": "Email",
              "displayName": "Email",
              "required": false,
              "defaultMatch": false,
              "display": true,
              "type": "string",
              "canBeUsedToMatch": true
            },
            {
              "id": "Message",
              "displayName": "Message",
              "required": false,
              "defaultMatch": false,
              "display": true,
              "type": "string",
              "canBeUsedToMatch": true
            },
            {
              "id": "Timestamp",
              "displayName": "Timestamp",
              "required": false,
              "defaultMatch": false,
              "display": true,
              "type": "string",
              "canBeUsedToMatch": true
            }
          ],
          "attemptToConvertTypes": false,
          "convertFieldsToString": false
        },
        "options": {

        }
      },
      "type": "n8n-nodes-base.googleSheets",
      "typeVersion": 4.7,
      "position": [624, 0],
      "id": "6370ec5a-776b-4007-9931-17fd2f1a75be",
      "name": "Append row in sheet",
      "credentials": {
        "googleSheetsOAuth2Api": {
          "id": "HqHt47uNPjpk4SFF",
          "name": "Google Sheets account"
        }
      }
    },
    {
      "parameters": {
        "sendTo": "wadoodk212@gmail.com",
        "subject": "We recieved you Submission",
        "message": "=Hi Abdul Wadood,  Thanks for reaching out — we've received your message: We'll be in touch soon.",
        "options": {

        }
      },
      "type": "n8n-nodes-base.gmail",
      "typeVersion": 2.2,
      "position": [832, 0],
      "id": "86dd3589-f4bc-4183-ab43-cd6a39381040",
      "name": "Send a message",
      "webhookId": "aa41c4ba-447e-4a49-b6b0-069059418a9e",
      "credentials": {
        "gmailOAuth2": {
          "id": "jYE3IuNJMsHFVKYn",
          "name": "Gmail account"
        }
      }
    }
  ],
  "pinData": {

  },
  "connections": {
    "Webhook": {
      "main": [
        [
          {
            "node": "Edit Fields",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Edit Fields": {
      "main": [
        [
          {
            "node": "Filter",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Filter": {
      "main": [
        [
          {
            "node": "Append row in sheet",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Append row in sheet": {
      "main": [
        [
          {
            "node": "Send a message",
            "type": "main",
            "index": 0
          }
        ]
      ]
    }
  },
  "active": false,
  "settings": {
    "executionOrder": "v1",
    "binaryMode": "separate"
  },
  "versionId": "c99e29f1-45a5-46c0-9447-e80e80f51e4a",
  "meta": {
    "templateCredsSetupCompleted": true,
    "instanceId": "854f34b4ed7db77ccb3a9c25a45847fc205f644339f1b150a22247a3bc76bf7b"
  },
  "nodeGroups": [],
  "id": "Ogai1YTM3MLrtp6X",
  "tags": []
}